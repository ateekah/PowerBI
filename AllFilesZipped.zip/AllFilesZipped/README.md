# PowerBI
Keep Track of your Running with a PowerBI template

Download the TrackRunning.pbix file and times.tsv files

Download and install newer PowerBI client from https://powerbi.microsoft.com/en-us/desktop/

Open the TrackRunning.pbix file

Point to the times.tsv file
